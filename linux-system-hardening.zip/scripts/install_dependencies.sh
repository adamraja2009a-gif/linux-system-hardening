#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/common.sh"
usage(){ cat <<USAGE
Usage: sudo ./scripts/install_dependencies.sh [--dry-run] [--verbose]
Propose l'installation de UFW, BATS, ShellCheck et auditd s'ils sont absents.
USAGE
}
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; *) fail "Option inconnue: $1"; exit 2;; esac; shift; done
require_root || exit $?
log_start
source /etc/os-release
[[ ${ID:-} == ubuntu ]] || { fail 'Ubuntu requis.'; exit 1; }
missing=()
for p in ufw auditd; do dpkg -s "$p" >/dev/null 2>&1 || missing+=("$p"); done
command -v bats >/dev/null || missing+=(bats)
command -v shellcheck >/dev/null || missing+=(shellcheck)
if ((${#missing[@]}==0)); then pass 'Toutes les dépendances optionnelles sont déjà installées.'; exit 0; fi
info "Paquets candidats: ${missing[*]}"
if ! confirm 'Installer ces paquets avec APT ?'; then warn 'Installation annulée.'; exit 3; fi
run apt-get update
run apt-get install -y "${missing[@]}"
pass 'Installation terminée. Une configuration spécifique auditd peut nécessiter une validation manuelle.'
