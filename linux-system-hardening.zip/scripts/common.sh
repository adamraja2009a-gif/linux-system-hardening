#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKUP_ROOT="$ROOT_DIR/evidence/backups"
LOG_DIR="$ROOT_DIR/evidence"
mkdir -p "$BACKUP_ROOT" "$LOG_DIR"

DRY_RUN=false
VERBOSE=false
LOG_FILE=""

info(){ printf '[INFO] %s\n' "$*"; }
pass(){ printf '[PASS] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }
fail(){ printf '[FAIL] %s\n' "$*" >&2; }
verbose(){ $VERBOSE && printf '[DEBUG] %s\n' "$*" || true; }

usage_common(){
  cat <<USAGE
Options communes:
  --help       Affiche l'aide
  --dry-run    N'effectue aucune modification
  --verbose    Active les messages détaillés
USAGE
}

require_root(){
  if [[ $EUID -ne 0 ]]; then fail 'Ce script nécessite root/sudo.'; return 2; fi
}

run(){
  if $DRY_RUN; then info "DRY-RUN: $*"; return 0; fi
  verbose "Exécution: $*"
  "$@"
}

confirm(){
  local prompt=${1:-'Continuer ?'}
  if $DRY_RUN; then return 0; fi
  read -r -p "$prompt [y/N] " answer
  [[ "$answer" =~ ^[YyOo]$ ]]
}

backup_file(){
  local src=$1 backup_dir=$2 rel
  if [[ ! -e "$src" && ! -L "$src" ]]; then
    rel="${src#/}"
    mkdir -p "$backup_dir/$(dirname "$rel")"
    : > "$backup_dir/$rel.absent"
    warn "Fichier absent, marqueur créé: $src"
    return 0
  fi
  rel="${src#/}"
  mkdir -p "$backup_dir/$(dirname "$rel")"
  cp -a -- "$src" "$backup_dir/$rel"
  stat -c '%U %G %a' -- "$src" > "$backup_dir/$rel.metadata"
}

new_backup(){
  local stamp dir
  stamp="$(date +%Y%m%d_%H%M%S)"
  dir="$BACKUP_ROOT/$stamp"
  local n=0 candidate="$dir"
  while [[ -e "$candidate" ]]; do ((n+=1)); candidate="${dir}_$n"; done
  if $DRY_RUN; then
    printf '%s\n' "$candidate"
    return 0
  fi
  mkdir -p "$candidate"
  printf '%s\n' "$candidate"
}

restore_tree(){
  local backup_dir=$1 rel src
  [[ -d "$backup_dir" ]] || { fail "Backup introuvable: $backup_dir"; return 1; }
  while IFS= read -r -d '' src; do
    rel="${src#"$backup_dir/"}"
    if [[ "$rel" == *.absent ]]; then
      target="/${rel%.absent}"
      if [[ -e "$target" || -L "$target" ]]; then run rm -f -- "$target"; fi
      continue
    fi
    [[ "$rel" == *.metadata ]] && continue
    [[ "$rel" == *'/.'* || "$rel" == '.git'* ]] && continue
    if [[ "$rel" == usr/local/* || "$rel" == etc/* || "$rel" == var/* ]]; then
      run mkdir -p "/$(dirname "$rel")"
      run cp -a -- "$src" "/$rel"
      local meta="$src.metadata"
      if [[ -f "$meta" ]]; then
        local owner group mode
        read -r owner group mode < "$meta" || true
        if [[ -n "${owner:-}" && -n "${group:-}" && -n "${mode:-}" ]]; then
          run chown "$owner:$group" "/$rel"
          run chmod "$mode" "/$rel"
        fi
      fi
    fi
  done < <(find "$backup_dir" -type f -print0)
}

log_start(){
  LOG_FILE="$LOG_DIR/$(basename "$0" .sh)_$(date +%Y%m%d_%H%M%S).log"
  exec > >(tee -a "$LOG_FILE") 2>&1
}

trap 'rc=$?; if ((rc!=0)); then fail "Arrêt sur erreur (code $rc), ligne ${BASH_LINENO[0]:-?}."; fi' EXIT
