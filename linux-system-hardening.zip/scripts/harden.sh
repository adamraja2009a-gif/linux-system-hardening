#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
source "$(dirname "$0")/common.sh"
SSH_PORT=22; DISABLE_SSH_PASSWORD=false; SKIP_UPDATES=false
usage(){ cat <<USAGE
Usage: sudo ./scripts/harden.sh [--dry-run] [--verbose] [--ssh-port PORT] [--disable-ssh-password] [--skip-updates]
USAGE
}
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; --ssh-port) [[ $# -ge 2 ]] || { fail 'Port manquant'; exit 2; }; SSH_PORT=$2; shift;; --disable-ssh-password) DISABLE_SSH_PASSWORD=true;; --skip-updates) SKIP_UPDATES=true;; *) fail "Option inconnue: $1"; usage; exit 2;; esac; shift; done
[[ "$SSH_PORT" =~ ^[0-9]+$ ]] && ((SSH_PORT>=1 && SSH_PORT<=65535)) || { fail 'Port SSH invalide'; exit 2; }
require_root || exit $?
log_start

pre_args=(); $DRY_RUN && pre_args+=(--dry-run); $VERBOSE && pre_args+=(--verbose)
"$(dirname "$0")/precheck.sh" "${pre_args[@]}"

if ! $SKIP_UPDATES; then
  info 'Simulation des mises à jour disponibles (aucune release upgrade).'
  apt-get -s upgrade 2>/dev/null | awk '/^Inst / {print}' || warn 'Simulation APT indisponible.'
  if confirm 'Installer les mises à jour disponibles ?'; then run apt-get update; run env DEBIAN_FRONTEND=noninteractive apt-get upgrade -y; fi
fi

BACKUP_DIR=$(new_backup); info "Backup prévu: $BACKUP_DIR"
if ! $DRY_RUN; then for f in /etc/ssh/sshd_config /etc/sysctl.conf /etc/ufw/user.rules /etc/ufw/user6.rules; do backup_file "$f" "$BACKUP_DIR"; done; fi

if command -v sshd >/dev/null 2>&1; then
  run mkdir -p /etc/ssh/sshd_config.d
  if ! $DRY_RUN; then backup_file /etc/ssh/sshd_config.d/99-linux-hardening.conf "$BACKUP_DIR"; fi
  ssh_dropin=/etc/ssh/sshd_config.d/99-linux-hardening.conf
  cat > /tmp/99-linux-hardening.conf <<'EOF2'
# Managed by linux-system-hardening. Review locally before production use.
PermitRootLogin no
MaxAuthTries 4
LoginGraceTime 30
X11Forwarding no
AllowTcpForwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
EOF2
  if $DRY_RUN; then info "DRY-RUN: écrirait $ssh_dropin"; else install -m 0644 /tmp/99-linux-hardening.conf "$ssh_dropin"; fi
  if $DISABLE_SSH_PASSWORD; then
    key_found=false
    while IFS=: read -r _ _ _ _ _ home _; do [[ -f "$home/.ssh/authorized_keys" ]] && { key_found=true; break; }; done < /etc/passwd
    if $key_found && confirm 'Désactiver PasswordAuthentication après détection d’une clé ?'; then
      if $DRY_RUN; then info 'DRY-RUN: ajouterait PasswordAuthentication no'; elif ! grep -q '^PasswordAuthentication no$' "$ssh_dropin" 2>/dev/null; then printf '%s\n' 'PasswordAuthentication no' >> "$ssh_dropin"; fi
    else warn 'PasswordAuthentication conservé pour limiter le risque de lockout.'; fi
  fi
  # Toujours tester la configuration réelle avant reload.
  if $DRY_RUN; then info 'DRY-RUN: sshd -t sur la configuration actuelle (aucune modification appliquée).'; else sshd -t || { fail 'sshd -t échoue; SSH ne sera pas rechargé.'; exit 1; }; fi
  if confirm 'Recharger SSH maintenant ?'; then run systemctl reload ssh || run systemctl reload sshd; fi
else warn 'SSH absent; étape ignorée.'; fi

if ! command -v ufw >/dev/null 2>&1; then
  if confirm 'Installer UFW ?'; then run apt-get update; run apt-get install -y ufw; else warn 'UFW absent et non installé.'; fi
fi
if command -v ufw >/dev/null 2>&1; then
  if ! $DRY_RUN; then backup_file /etc/ufw/user.rules "$BACKUP_DIR"; backup_file /etc/ufw/user6.rules "$BACKUP_DIR"; fi
  if confirm 'Préparer UFW (deny incoming, allow outgoing, SSH autorisé avant activation) ?'; then
    run ufw default deny incoming
    run ufw default allow outgoing
    run ufw allow "$SSH_PORT/tcp" comment 'SSH administrative access'
    info 'État/règles avant activation:'; ufw status verbose || true
    if confirm 'Activer UFW maintenant ?'; then run ufw --force enable; else warn 'UFW préparé mais non activé.'; fi
  fi
fi

sysctl_file=/etc/sysctl.d/99-linux-hardening.conf
if ! $DRY_RUN; then backup_file "$sysctl_file" "$BACKUP_DIR"; fi
if confirm 'Appliquer le baseline sysctl ?'; then
  if $DRY_RUN; then info "DRY-RUN: écrirait $sysctl_file"; else install -m 0644 "$ROOT_DIR/config/sysctl-hardening.conf" "$sysctl_file"; fi
  while IFS='=' read -r key value; do
    key=$(printf '%s' "$key" | xargs); value=$(printf '%s' "$value" | xargs)
    [[ -z "$key" || "$key" == \#* ]] && continue
    proc="/proc/sys/${key//./\/}"
    if [[ ! -e "$proc" ]]; then warn "Paramètre non exposé: $key"; continue; fi
    if $DRY_RUN; then info "DRY-RUN: sysctl -w $key=$value"; else sysctl -w "$key=$value" >/dev/null; actual=$(sysctl -n "$key"); [[ "$actual" == "$value" ]] || { fail "Valeur inattendue: $key=$actual"; exit 1; }; pass "$key=$actual"; fi
  done < "$ROOT_DIR/config/sysctl-hardening.conf"
fi

systemctl is-active --quiet systemd-journald && pass 'journald actif' || warn 'journald non actif/détectable.'
if ! command -v auditctl >/dev/null 2>&1; then
  if confirm 'Installer auditd ?'; then run apt-get update; run apt-get install -y auditd; run systemctl enable --now auditd; else warn 'auditd non installé.'; fi
else pass 'auditctl disponible'; fi

pass "Hardening terminé. Backup: $BACKUP_DIR"
