#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
source "$(dirname "$0")/common.sh"

usage(){ cat <<USAGE
Usage: sudo ./scripts/precheck.sh [--dry-run] [--verbose]
Vérifie prérequis Ubuntu/systemd/SSH/UFW/permissions/espace/dépendances.
USAGE
}
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; *) fail "Option inconnue: $1"; usage; exit 2;; esac; shift; done
require_root || exit $?
log_start

critical=0
command -v systemctl >/dev/null && pass 'systemctl disponible' || { fail 'systemctl absent'; critical=1; }
source /etc/os-release
if [[ ${ID:-} == ubuntu ]]; then pass "Ubuntu détecté: ${PRETTY_NAME:-unknown}"; else fail "Système non Ubuntu: ${ID:-unknown}"; critical=1; fi
arch=$(dpkg --print-architecture 2>/dev/null || uname -m); info "Architecture: $arch"
if systemctl is-system-running >/dev/null 2>&1; then pass 'systemd opérationnel'; else warn 'systemd est présent mais le système n’est pas dans un état fully-running (acceptable en conteneur/VM particulière).'; fi
free_kb=$(df -Pk / | awk 'NR==2 {print $4}'); if ((free_kb < 1048576)); then warn 'Moins de 1 GiB libre sur /'; else pass 'Espace disque >= 1 GiB'; fi
for c in awk sed grep find stat cp chmod chown systemctl; do command -v "$c" >/dev/null && pass "Dépendance: $c" || { fail "Dépendance absente: $c"; critical=1; }; done
[[ -r /etc/passwd && -r /etc/group ]] && pass 'Fichiers utilisateurs lisibles' || { fail 'Impossible de lire passwd/group'; critical=1; }
[[ -r /etc/ssh/sshd_config ]] && pass 'Configuration SSH présente' || warn 'sshd_config absent: SSH peut ne pas être installé.'
command -v sshd >/dev/null && { sshd -t && pass 'sshd -t valide' || { fail 'Configuration SSH invalide'; critical=1; }; } || warn 'sshd absent.'
command -v ufw >/dev/null && pass 'UFW installé' || warn 'UFW absent; install_dependencies.sh peut le proposer.'
[[ -w "$ROOT_DIR/evidence" ]] && pass 'Répertoire evidence inscriptible' || { fail 'evidence non inscriptible'; critical=1; }
if ((critical)); then fail 'Pré-check critique échoué. Aucun hardening ne doit commencer.'; exit 1; fi
pass 'Pré-check terminé.'
