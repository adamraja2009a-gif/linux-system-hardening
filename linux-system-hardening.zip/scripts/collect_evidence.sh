#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/common.sh"
usage(){ echo 'Usage: sudo ./scripts/collect_evidence.sh [--dry-run] [--verbose]'; }
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; *) fail "Option inconnue: $1"; exit 2;; esac; shift; done
require_root || exit $?
log_start
out="$ROOT_DIR/evidence/evidence_$(date +%Y%m%d_%H%M%S).txt"
if $DRY_RUN; then info "DRY-RUN: rapport $out"; exit 0; fi
umask 077
{
 echo 'Linux System Hardening — Non-sensitive Evidence Report'
 echo "Audit date: $(date --iso-8601=seconds)"
 echo "OS: $(. /etc/os-release; printf '%s' "${PRETTY_NAME:-unknown}")"
 echo "Kernel: $(uname -r)"; echo "Architecture: $(uname -m)"
 echo; echo '=== UFW ==='; command -v ufw >/dev/null && ufw status verbose || echo 'UFW absent'
 echo; echo '=== SSH non-sensitive ==='; if command -v sshd >/dev/null; then sshd -T 2>/dev/null | grep -E '^(port|listenaddress|permitrootlogin|passwordauthentication|maxauthtries|logingracetime|x11forwarding|allowtcpforwarding|clientaliveinterval|clientalivecountmax) '; else echo 'SSH absent'; fi
 echo; echo '=== Sysctl ==='; for p in net.ipv4.conf.all.accept_redirects net.ipv4.conf.default.accept_redirects net.ipv4.conf.all.accept_source_route net.ipv4.conf.default.accept_source_route net.ipv4.conf.all.send_redirects net.ipv4.conf.default.send_redirects net.ipv6.conf.all.accept_redirects net.ipv6.conf.default.accept_redirects net.ipv6.conf.all.accept_source_route net.ipv6.conf.default.accept_source_route; do [[ -e "/proc/sys/${p//./\/}" ]] && printf '%s=%s\n' "$p" "$(sysctl -n "$p")"; done
 echo; echo '=== Users/groups (names only) ==='; cut -d: -f1,3 /etc/passwd; echo '--- groups ---'; cut -d: -f1 /etc/group
 echo; echo '=== Sensitive permissions ==='; for f in /etc/passwd /etc/group /etc/shadow /etc/sudoers; do [[ -e "$f" ]] && stat -c '%n owner=%U group=%G mode=%a' "$f"; done
 echo; echo '=== Active services (names only) ==='; systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk '{print $1}'
 echo; echo '=== Logs ==='; systemctl is-active systemd-journald 2>/dev/null || true; journalctl --disk-usage 2>/dev/null || true
 echo; echo '=== Auditd ==='; if command -v auditctl >/dev/null; then auditctl -s 2>/dev/null | head -10; else echo 'auditctl absent'; fi
 echo; echo '=== Updates ==='; apt-get -s upgrade 2>/dev/null | awk '/^Inst /{print $2}' | head -100
} > "$out"
chmod 0600 "$out"
pass "Evidence générée: $out (mode 0600, sans mots de passe/clés/tokens/cookies)"
