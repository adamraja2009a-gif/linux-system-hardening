#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/common.sh"
LIST=false; SELECTED=''
usage(){ echo 'Usage: sudo ./scripts/rollback.sh [--list] [--dry-run] [--verbose]'; }
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --list) LIST=true;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; *) fail "Option inconnue: $1"; exit 2;; esac; shift; done
require_root || exit $?
log_start
mapfile -t backups < <(find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort -r)
if ((${#backups[@]}==0)); then warn 'Aucun backup disponible.'; exit 0; fi
if $LIST; then printf '%s\n' "${backups[@]}"; exit 0; fi
printf 'Backups disponibles:\n'; printf '  %s\n' "${backups[@]}"
read -r -p 'Nom exact du backup à restaurer: ' SELECTED
found=false; for b in "${backups[@]}"; do [[ "$b" == "$SELECTED" ]] && found=true; done; $found || { fail 'Backup non trouvé.'; exit 2; }
backup_dir="$BACKUP_ROOT/$SELECTED"
confirm "Restaurer $SELECTED ?" || { warn 'Rollback annulé.'; exit 3; }
# Pré-valider les fichiers de configuration après copie, puis restaurer/revalider.
restore_tree "$backup_dir"
if command -v sshd >/dev/null 2>&1; then sshd -t || { fail 'Après restauration, sshd -t échoue. Ne pas recharger SSH; corriger depuis la console.'; exit 1; fi
if command -v ufw >/dev/null 2>&1; then ufw status verbose || true; fi
pass "Rollback terminé depuis $SELECTED. Un reload/reboot peut être nécessaire selon les fichiers restaurés."
