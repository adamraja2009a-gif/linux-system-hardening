#!/usr/bin/env bash
set -Eeuo pipefail
source "$(dirname "$0")/common.sh"
usage(){ echo 'Usage: sudo ./scripts/audit.sh [--dry-run] [--verbose]'; }
while (($#)); do case "$1" in --help|-h) usage; exit 0;; --dry-run) DRY_RUN=true;; --verbose|-v) VERBOSE=true;; *) fail "Option inconnue: $1"; exit 2;; esac; shift; done
require_root || exit $?
log_start
printf 'Linux System Hardening Audit — %s\n' "$(date --iso-8601=seconds)"
check(){ local label=$1; shift; if "$@"; then pass "$label"; else warn "$label"; return 1; fi; }
source /etc/os-release; info "OS: ${PRETTY_NAME:-unknown}"; info "Kernel: $(uname -r)"; info "Arch: $(uname -m)"
updates=$(apt-get -s upgrade 2>/dev/null | awk '/^Inst /{c++} END{print c+0}'); ((updates==0)) && pass 'Aucune mise à jour standard en attente' || warn "$updates paquet(s) pouvant être mis à jour"
command -v ufw >/dev/null && { ufw status verbose || true; ufw status | grep -qi active && pass 'UFW actif' || warn 'UFW inactif'; ufw status | grep -Eq "${SSH_PORT:-22}/tcp|OpenSSH" 2>/dev/null && pass 'Règle SSH visible' || warn 'Règle SSH non détectée (vérifier le port)'; } || warn 'UFW absent'
if command -v sshd >/dev/null; then sshd -t && pass 'sshd -t valide' || fail 'sshd -t invalide'; cfg=$(sshd -T 2>/dev/null || true); grep -q '^permitrootlogin no$' <<<"$cfg" && pass 'Root login SSH désactivé' || warn 'Root login SSH non désactivé'; grep -q '^passwordauthentication no$' <<<"$cfg" && pass 'PasswordAuthentication désactivé' || warn 'PasswordAuthentication encore activé'; else warn 'SSH absent'; fi
awk -F: '$3==0{print $1}' /etc/passwd | while read -r u; do [[ "$u" == root ]] && continue; warn "UID 0 supplémentaire: $u"; done
awk -F: '($2=="") {print $1}' /etc/shadow 2>/dev/null | head -20 | while read -r u; do [[ -n "$u" ]] && warn "Compte avec champ mot de passe vide: $u"; done
for f in /etc/passwd /etc/group /etc/shadow /etc/sudoers; do [[ -e "$f" ]] || continue; perm=$(stat -c '%a %U:%G' "$f"); info "$f => $perm"; done
if getent group sudo >/dev/null 2>&1; then info 'Membres du groupe sudo:'; getent group sudo | cut -d: -f4 | tr ',' '\n' | sed '/^$/d' | while read -r u; do info "sudo: $u"; done; else warn 'Groupe sudo absent'; fi
find /etc -xdev -type f -perm /022 -print 2>/dev/null | head -50 | while read -r f; do warn "Fichier sous /etc writable par groupe/autres: $f"; done
systemctl is-active --quiet systemd-journald && pass 'journald actif' || warn 'journald non actif'; command -v auditctl >/dev/null && auditctl -s 2>/dev/null | head -5 || warn 'auditd/auditctl absent'
for p in net.ipv4.conf.all.accept_redirects net.ipv4.conf.all.accept_source_route net.ipv4.conf.all.send_redirects; do if [[ -e "/proc/sys/${p//./\/}" ]]; then v=$(sysctl -n "$p"); [[ "$v" == 0 ]] && pass "$p=0" || warn "$p=$v"; fi; done
count=$(find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l); if ((count>0)); then pass "$count backup(s) disponibles"; latest=$(find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-); info "Backup le plus récent: $(basename "$latest")"; else warn 'Aucun backup disponible'; fi
info "Dernier audit: $(date --iso-8601=seconds)"
