#!/usr/bin/env bash
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
bash "$ROOT/scripts/precheck.sh" --help >/dev/null || exit 1
if bash "$ROOT/scripts/precheck.sh" --unknown >/dev/null 2>&1; then echo 'FAIL: unknown option accepted'; exit 1; fi
echo 'PASS: precheck interface tests'
