#!/usr/bin/env bash
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
bash "$ROOT/scripts/harden.sh" --help >/dev/null || exit 1
if bash "$ROOT/scripts/harden.sh" --unknown >/dev/null 2>&1; then echo 'FAIL: unknown option accepted'; exit 1; fi
if bash "$ROOT/scripts/harden.sh" --ssh-port 0 >/dev/null 2>&1; then echo 'FAIL: invalid port accepted'; exit 1; fi
echo 'PASS: hardening interface tests'
