#!/usr/bin/env bats
ROOT="$BATS_TEST_DIRNAME/../.."
@test "help precheck" { run "$ROOT/scripts/precheck.sh" --help; [ "$status" -eq 0 ]; }
@test "help harden" { run "$ROOT/scripts/harden.sh" --help; [ "$status" -eq 0 ]; }
@test "help audit" { run "$ROOT/scripts/audit.sh" --help; [ "$status" -eq 0 ]; }
@test "help rollback" { run "$ROOT/scripts/rollback.sh" --help; [ "$status" -eq 0 ]; }
@test "unknown option rejected" { run "$ROOT/scripts/audit.sh" --bad; [ "$status" -eq 2 ]; }
