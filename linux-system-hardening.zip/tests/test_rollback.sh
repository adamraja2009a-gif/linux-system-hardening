#!/usr/bin/env bash
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
bash "$ROOT/scripts/rollback.sh" --help >/dev/null || exit 1
bash "$ROOT/scripts/rollback.sh" --list >/dev/null 2>&1 || true
echo 'PASS: rollback interface tests'
