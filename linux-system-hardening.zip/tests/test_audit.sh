#!/usr/bin/env bash
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
bash "$ROOT/scripts/audit.sh" --help >/dev/null || exit 1
if bash "$ROOT/scripts/audit.sh" --unknown >/dev/null 2>&1; then echo 'FAIL: unknown option accepted'; exit 1; fi
echo 'PASS: audit interface tests'
