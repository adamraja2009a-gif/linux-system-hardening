# Linux System Hardening Lab — Ubuntu Server

Projet de portfolio défensif réalisé exclusivement dans une VM Ubuntu Server locale sous VirtualBox. Il automatise avec prudence des contrôles de sécurité, des sauvegardes, un hardening SSH/UFW/sysctl, un audit et un rollback.

> **Important :** aucun système externe n'est ciblé. Le projet n'affirme jamais qu'un système est sécurisé à 100 %. Les changements critiques demandent confirmation et une console VM reste le mécanisme de récupération privilégié.

## Objectifs
- Comprendre le hardening Linux et le principe de moindre privilège.
- Automatiser des contrôles reproductibles en Bash.
- Sécuriser SSH sans provoquer de lockout volontaire.
- Déployer UFW avec SSH autorisé avant activation.
- Appliquer un petit baseline sysctl documenté.
- Produire des preuves non sensibles et restaurables.
- Tester idempotence, erreurs et rollback.

## Architecture
```text
Utilisateur -> precheck.sh -> harden.sh
                         |       |-- backup timestampé
                         |       |-- SSH (sshd -t)
                         |       |-- UFW
                         |       |-- sysctl
                         |       |-- journald/auditd
                         v
                      audit.sh -> evidence/rapport
                         ^
                         |
                    rollback.sh
```

## Prérequis
- VirtualBox et une VM Ubuntu Server 22.04/24.04/25.04 ou version proche.
- Accès console à la VM.
- Compte administrateur avec sudo.
- Snapshot VirtualBox recommandé avant le premier hardening.
- Internet seulement pour l'installation initiale des paquets si nécessaire; aucun scan externe n'est effectué.

## Installation
```bash
git clone <URL-DE-VOTRE-REPO> linux-system-hardening
cd linux-system-hardening
chmod +x scripts/*.sh tests/*.sh
./scripts/precheck.sh --help
sudo ./scripts/install_dependencies.sh --help
```
Le projet ne change pas automatiquement le port SSH. Le port peut être fourni explicitement à UFW.

## Utilisation
### Pré-check
```bash
sudo ./scripts/precheck.sh
sudo ./scripts/precheck.sh --dry-run --verbose
```

### Hardening
Commencer par :
```bash
sudo ./scripts/harden.sh --dry-run --verbose
```
Puis, dans la VM avec console ouverte :
```bash
sudo ./scripts/harden.sh --verbose
```
Le script demande confirmation pour les étapes critiques. Pour SSH, il ne désactive le mot de passe que si une clé autorisée existe et après confirmation explicite.

### Audit
```bash
sudo ./scripts/audit.sh --verbose
```
L'audit est en lecture seule.

### Preuves
```bash
sudo ./scripts/collect_evidence.sh --verbose
```
Les rapports sont écrits dans `evidence/`. Vérifier qu'ils ne contiennent aucune donnée sensible avant commit.

### Rollback
```bash
sudo ./scripts/rollback.sh --list
sudo ./scripts/rollback.sh
```
Le rollback restaure fichiers, propriétaires et permissions. Les sauvegardes ne sont jamais supprimées.

## Mises à jour
Le script affiche les mises à jour disponibles. Les mises à jour sont séparées du hardening et nécessitent confirmation. Aucune release upgrade (`do-release-upgrade`) n'est exécutée automatiquement.

## Tests
Si BATS est installé :
```bash
bats tests/bats
```
Sinon :
```bash
./tests/test_precheck.sh
./tests/test_hardening.sh
./tests/test_audit.sh
./tests/test_rollback.sh
```
Certains tests réels nécessitent root et une VM Ubuntu. Les tests unitaires non destructifs utilisent des mocks lorsque possible.

## Résultats attendus
- `precheck.sh`: pas de FAIL critique sur Ubuntu VM correctement préparée.
- `harden.sh --dry-run`: aucune modification.
- `audit.sh`: PASS/WARN/FAIL/INFO avec justification.
- Deux exécutions du hardening ne doivent pas produire de dérive fonctionnelle.
- `rollback.sh`: restauration vérifiée par hash/permissions lorsque possible.

## Captures d'écran à ajouter
1. `precheck.sh` avec PASS/WARN/INFO.
2. `harden.sh --dry-run`.
3. `sshd -t` puis statut SSH.
4. `ufw status verbose`.
5. `audit.sh` final.
6. Sélection d'un backup et rollback.
7. Arborescence GitHub.

## Dépannage
- **SSH inaccessible** : ne pas modifier à distance; utiliser la console VirtualBox, vérifier `sshd -t`, UFW et le port d'écoute.
- **UFW bloque le trafic** : `sudo ufw status numbered`, puis rollback ou `sudo ufw disable` depuis la console.
- **sysctl refusé** : consulter le log; certains paramètres peuvent différer selon kernel/Ubuntu.
- **auditd absent** : l'installation peut nécessiter le dépôt Ubuntu approprié et un redémarrage du service.
- **permissions** : exécuter avec sudo; ne jamais lancer les scripts depuis un répertoire contrôlé par un utilisateur non fiable.

## Limites
Ce laboratoire ne remplace ni CIS Benchmark, ni OpenSCAP, ni EDR, ni revue humaine. Les valeurs sysctl et SSH varient selon Ubuntu et le contexte. Les règles UFW proposées sont minimales. Le modèle de menace n'inclut pas un attaquant ayant déjà root/kernel compromise.

## Améliorations possibles
- Intégration OpenSCAP/CIS en mode lecture seule.
- CI GitHub pour ShellCheck + BATS.
- Export JSON signé des preuves.
- Tests Matrix Ubuntu 22.04/24.04.
- Intégration fail2ban après étude d'impact.
- Ansible/Terraform pour reproduire la VM, sans supprimer la version Bash pédagogique.

## Présentation GitHub
Repository conseillé : `linux-system-hardening` avec README, captures dans `docs/screenshots/`, issues de test et changelog. Ne jamais pousser les rapports contenant des données personnelles ou des secrets.

## Dossier universitaire
Présenter le problème, le threat model, le baseline, les choix techniques, les contrôles avant/après, les tests, les limites et une démonstration de rollback.

## Auteur
**Étudiant cybersécurité — Linux Defensive Security Lab**
