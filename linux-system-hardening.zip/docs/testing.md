# Testing

## Tests automatisés
- Interface `--help`.
- Options inconnues rejetées avec code 2.
- Tests BATS des interfaces.
- ShellCheck recommandé.
- Tests réels root sur VM : UFW, sshd, sysctl, backups, rollback.

## Scénarios manuels
1. VM non Ubuntu : `precheck.sh` doit refuser.
2. SSH absent : hardening doit avertir sans échouer sur une étape inexistante.
3. Mauvaise configuration SSH : `sshd -t` doit empêcher reload.
4. Dry-run : aucune modification de configuration.
5. Première exécution : backup créé.
6. Deuxième exécution : pas de duplication fonctionnelle des directives UFW/SSH.
7. Rollback : vérifier permissions/propriétaires et `sshd -t` avant reload.
8. Audit avant/après : comparer PASS/WARN/FAIL.

## Indépendance réseau
Les tests n'utilisent pas Internet ni un serveur de production. L'installation des dépendances est la seule étape pouvant utiliser APT.
