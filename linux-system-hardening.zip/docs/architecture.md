# Architecture

Le laboratoire est local : VirtualBox héberge une VM Ubuntu Server. Les scripts exécutent uniquement des commandes locales.

## Composants
- `precheck.sh` : garde-fou avant action.
- `harden.sh` : orchestration contrôlée.
- `audit.sh` : contrôle lecture seule.
- `collect_evidence.sh` : preuves non sensibles.
- `rollback.sh` : restauration depuis backups.
- `common.sh` : fonctions communes, mode strict, logs et backups.

## Flux
`precheck -> backup -> SSH -> UFW -> sysctl -> logs/auditd -> audit/evidence`.

Aucun composant ne scanne Internet, ne contacte une cible distante ou ne supprime un utilisateur.
