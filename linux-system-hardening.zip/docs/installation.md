# Installation de la VM

1. Créer une VM Ubuntu Server dans VirtualBox.
2. Donner au moins 2 vCPU, 2–4 Go RAM et 20 Go disque pour le laboratoire.
3. Installer OpenSSH Server seulement si nécessaire pour la démonstration.
4. Créer un compte administrateur normal avec sudo.
5. Prendre un snapshot VirtualBox avant hardening.
6. Copier/cloner le dépôt dans la VM.
7. Exécuter `chmod +x scripts/*.sh tests/*.sh`.
8. Lancer `sudo ./scripts/precheck.sh --verbose`.

Le réseau NAT/host-only peut être utilisé pour un laboratoire isolé. Aucun scan de plage, aucun test contre Internet et aucune cible tierce n'est nécessaire.
