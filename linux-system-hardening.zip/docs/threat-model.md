# Threat Model

## Actifs
- Compte administrateur.
- Configuration SSH.
- Firewall local.
- Intégrité des paramètres réseau.
- Logs système.

## Menaces
- Tentatives d'authentification SSH abusives.
- Exposition réseau inutile.
- Mauvaises permissions locales.
- Configuration faible ou oubliée.
- Perte de configuration après modification.

## Hypothèses
- L'étudiant contrôle la VM et sa console.
- L'hôte VirtualBox est de confiance pour le laboratoire.
- Le kernel et Ubuntu ne sont pas déjà compromis.

## Hors périmètre
- Attaquant root/kernel.
- Vulnérabilités applicatives.
- Sécurité physique.
- Attaques Internet réelles.
- Conformité complète CIS/PCI/ISO.
