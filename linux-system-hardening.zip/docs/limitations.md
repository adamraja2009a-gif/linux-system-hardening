# Limitations

- Les noms de services SSH (`ssh`/`sshd`) et certains paramètres varient selon Ubuntu.
- `auditd` peut être géré différemment selon version/kernel.
- Les paramètres sysctl IPv6 peuvent ne pas être exposés si IPv6 est désactivé ou différemment configuré.
- Le baseline n'est pas un benchmark CIS complet.
- Les règles UFW ne connaissent pas les besoins spécifiques d'une application.
- Le script ne détecte pas toutes les erreurs de configuration possibles.
- Un système compromis au niveau root/kernel ne peut pas être rendu fiable par ces scripts.
- Une revue humaine et des tests de connectivité sont obligatoires avant toute utilisation hors laboratoire.
