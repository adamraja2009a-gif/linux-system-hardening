# Security Baseline

| Contrôle | Valeur | Justification |
|---|---|---|
| SSH root | `PermitRootLogin no` | Réduit l'utilisation directe du compte privilégié. |
| SSH auth tries | 4 | Réduit les essais répétés par session. |
| Login grace | 30s | Limite une session d'authentification inactive. |
| X11 forwarding | no | Inutile sur un serveur standard. |
| TCP forwarding | no | Réduit une capacité de tunnel si non requise. |
| UFW incoming | deny | Principe de moindre exposition. |
| UFW outgoing | allow | Évite de casser les mises à jour et usages serveur courants. |
| Source routing | 0 | Généralement inutile sur un serveur classique. |
| ICMP redirects | 0 | Réduit les modifications de routes via redirects. |
| send redirects | 0 | Le serveur n'agit pas comme routeur. |

`PasswordAuthentication no` n'est jamais appliqué par défaut : il nécessite une clé `authorized_keys` détectée et une confirmation.

Les paramètres sysctl sont appliqués individuellement et seulement si la clé existe dans `/proc/sys`.
